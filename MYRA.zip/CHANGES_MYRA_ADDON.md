# MYRA add-on: modified / new files
(Original project is untouched where not listed. A copy of the original zip is the backup.)

## Modified (existing files)
- app/src/main/AndroidManifest.xml – new activities, VideoWallpaperService, ACCESS_NETWORK_STATE, live_wallpaper feature
- app/src/main/java/com/myra/assistant/services/ForegroundVoiceService.kt – transcripts→chat, reconnect/backoff, network watcher, phone-control hook, prompt lines
- app/src/main/java/com/myra/assistant/websocket/GeminiWebSocketClient.kt – shared OkHttp client, transcription, session resumption, stale-socket guard, goAway/close handling (same model, voice, key, audio format)
- app/src/main/java/com/myra/assistant/voice/AudioPlayer.kt – blocking queue (no 10 ms sleep), low-latency AudioTrack mode, dropPending(); lip-sync counters untouched
- app/src/main/java/com/myra/assistant/ui/main/MainActivity.kt – 3-button nav wiring (Chat/Voice/Settings)
- app/src/main/java/com/myra/assistant/ui/settings/SettingsActivity.kt – Live Wallpapers entry
- app/src/main/res/layout/activity_main.xml – bottom area replaced by the 3D glass 3-button bar (avatar/background untouched)
- app/src/main/res/layout/activity_settings.xml – Live Wallpapers card
- app/src/main/res/values/strings.xml – wallpaper description

## New
- data/ChatRepository.kt (shared persistent voice+text history)
- control/PhoneControl.kt (app launching, WhatsApp by number, confirm-before-send, websites, search)
- ui/chat/ChatActivity.kt, ChatMessagesAdapter.kt + layouts activity_chat, item_msg_*
- wallpaper/ CloudConfig, WallpaperItem, WallpaperRepository, ThumbLoader, VideoWallpaperService, WallpaperActivity, WallpaperDetailActivity + layouts
- assets/samples/ (2 real mp4 + thumbnails), res/xml/myra_wallpaper.xml, neon drawables/icons, drawable-nodpi/myra_avatar_thumb.png
- backend/ (admin web panel, firestore.rules, storage.rules, firebase.json, README_BACKEND.md)

## Later additions
- ui/main/SplashActivity (launcher) + splash_bg.jpg
- admin/AdminApi.kt, AdminLoginActivity.kt, AdminPanelActivity.kt (in-app password-protected admin panel, REST: Firebase Auth + Firestore + Storage)
- PhoneControl.executeTool + Gemini function calling (open_app, play_on_youtube, open_website, search_web, whatsapp_*, run_command) so voice commands really execute
- Settings & home 3D redesign, 4-button bottom card

- Backend switched from Firebase to Supabase (admin/AdminApi.kt, wallpaper/CloudConfig.kt, WallpaperRepository.kt, backend/supabase_setup.sql)
- control/UiAutomation.kt + control/WhatsAppAutomation.kt: in-app control through the Accessibility Service (read screen, tap, type, scroll, back/home) and WhatsApp by saved contact name (open chat, read messages, play voice message, type reply; send only after explicit yes); matching Gemini function declarations
- Faster replies: Gemini setup tuned (thinking budget 0, quicker end-of-speech detection) with automatic fallback
- utils/ApiKeys.kt: built-in default Gemini key (user's own key in Settings overrides it)
- Home bottom card: Chat · Voice · Wallpaper (Settings = top gear)
- Girlfriend Mode switch, Charging announce, Message announce (utils/Announcer.kt, service/MessageNotificationListener.kt)
- MyraApp (Application): crash guard (background-thread errors swallowed+logged, main-thread crash -> auto restart), PowerWatcher registered process-wide, thumbnails warmed at start
- ThumbLoader: permanent on-disk thumbnail cache (gallery opens instantly, works offline)
- Announcer/PowerWatcher: TTS created on main thread, Hindi voice or Roman fallback, announcement test button; Settings -> Last crash report
- Welcome dialog (WelcomeDialog + welcome_header.webp) with WhatsApp channel button; network banner (No internet connection / Poor network)
- Calls: CallControl (answer / end / speaker), answer_call + end_call voice tools, "phone pe baat karo" talk mode in CallAssistantActivity
- Default Gemini key is NOT in source anymore: injected at build time from GEMINI_DEFAULT_KEY
  (GitHub Actions secret, environment variable, or local.properties:  GEMINI_DEFAULT_KEY=your_key)
- design/: Premium Designs (26 Android / iOS / Premium looks) + Apps Box launcher-style screen (search, voice search, dock); Settings -> Premium Designs

## 3D character + new backgrounds (latest)
- res/drawable-nodpi/myra_bg_scene.jpg and splash_bg.jpg: replaced by the new neon MYRA artwork, 2160x3840 (same file names, so home / chat / settings / admin / wallpapers / splash all use it)
- res/drawable-nodpi/myra_character.webp: new 3D full-body character, background removed (transparent), 4K height (3840 px)
- ui/avatar/CharacterView.kt (new): draws the character, idle breathing, listening / thinking / speaking motion (speaking bounce follows the real voice level) and the actions below. Decodes the 4K file only at the size the screen needs.
- ui/avatar/CharacterActionBus.kt (new): dance, spin, jump, wave, bow, sway, stop
- Voice control: Gemini function `character_action` (GeminiWebSocketClient + PhoneControl.executeTool + prompt line in ForegroundVoiceService) plus a keyword fallback on the live transcript (naach / nacho / dance, ghoomo / spin, kudo / jump, wave, jhuko / bow, ruk jao / stop)
- activity_main.xml / MainActivity.kt: CharacterView added. The old AvatarStageView + crown are kept in the layout (visibility gone), nothing deleted. AvatarView, AvatarStageView, myra_avatar.png are untouched.
- myra_avatar_thumb.png (chat / dock icon): now the new character's face, 512 px
- welcome_header.webp, design_art_lock.webp, design_art_phantom.webp: upscaled 2-3x (Lanczos + sharpen)

## Character v2 (replaces the first 3D character)
- myra_character.webp: new transparent character, cropped head to mid-thigh (feet not shown), 4K height (2251x3840), lossless
- CharacterView: sits on the bottom edge of the screen behind the status panel / nav bar (close-up). New face rig: natural eye blinking, mouth opens with MYRA's real voice (LipSyncBus), hair / sleeve wave by mesh warp, plus dance / spin / jump / wave / bow / sway on command
- myra_avatar_thumb.png: face of the new character (512 px)

- utils/LiveAudioManager.kt: AudioPlaybackThread no longer throws InterruptedException when stop() interrupts it (normal shutdown is now handled quietly)

## Character v3
- CharacterView: character is now completely fixed on screen (no left/right/up/down drift); only commanded actions move it
- Hair: wind animation (gusts push the curls left and right, face stays still)
- Mouth: the picture's own lower lip + chin move down with the voice (mesh warp) with a dark mouth interior + teeth, instead of the pasted-on oval

## Voice fix + speed (latest)
- voice/VoiceStateManager.kt: mic can never stay blocked (watchdog), shorter mic tail (120 ms)
- voice/AudioPlayer.kt: play thread never dies, faster start (30 ms prime), low-latency AudioTrack
- voice/AudioRecorder.kt: mic init check, auto-restart on read errors
- services/ForegroundVoiceService.kt: tool calls always answered (12 s timeout), mic retry
- websocket/GeminiWebSocketClient.kt: faster end-of-speech (300 ms, HIGH)

## v3: voice restored to original audio code + safe fixes
- AudioRecorder / AudioPlayer sound settings / server VAD values: back to the original (working) versions
- Kept only logic-safe protections: mic watchdog, play thread never dies, tool call always answered (12 s), mic retry
- Network: IPv4-first DNS, ping 10 s, instant reconnect when Wi-Fi <-> mobile data switches

## v4: mobile data hardening
- SmartDns: current-network DNS -> system DNS -> DNS-over-HTTPS (Google/Cloudflare by IP); IPv4 first
- Socket pinned to the active network (Wi-Fi or mobile data); auto-fallback (DoH after 2 fails, unpinned after 4)
- Status now shows the reason: Reconnecting... (DNS / slow network / SSL / server rejected)

## App version 3.0.0 (versionCode 3): wallpaper fix
- WallpaperDetailActivity: preview now uses TextureView (no more black SurfaceView), centre-crop, safe release
- "Set wallpaper": every step wrapped, 3 fallback system screens, can no longer crash the app
- VideoWallpaperService: every callback guarded, surface validity check

## v5: real home screen + 100+ designs (additive only)
- New HomeLauncherActivity (category HOME + DEFAULT): the SAME themed real-app grid as Apps Box, now
  usable as the actual phone home screen. User picks it via Android's own "Set as Home" system prompt -
  MYRA never sets itself as default on its own.
- DesignsActivity: new "Real Home Screen par laga dein" button opens that system prompt.
- AppDesign.kt: 76 new designs added (nothing removed/changed) - 102 designs total across Premium/Android/iOS.
- Everything else (voice, mobile data, wallpaper fixes) unchanged from v3.0.0.

## MYRA Keyboard (real system keyboard / IME)
- keyboard/MyraKeyboardService.kt (InputMethodService: toolbar with emoji, clipboard history, themes, Select-All/Copy/Cut/Paste, settings; works in every app)
- keyboard/MyraKeyboardView.kt (canvas-drawn keys: 3D / Glass / Flat / Bubble / custom-PNG key styles, long-press alternates, key preview, shift + caps lock, symbols pages)
- keyboard/KbLayouts.kt (22 languages: English, Hindi, Marathi, Bengali, Punjabi, Gujarati, Odia, Tamil, Telugu, Kannada, Malayalam, Urdu, Arabic, Persian, Spanish, French, German, Portuguese, Italian, Turkish, Russian, Indonesian)
- keyboard/KbThemes.kt + assets/keyboard/* (12 image themes from the provided designs + 5 generated 3D themes + My Photo/PNG)
- keyboard/KeyboardSettingsActivity.kt (enable/select keyboard, theme grid, background + key PNG picker, opacity/height, options, languages)
- res/xml/method.xml, AndroidManifest.xml (service + activity), activity_settings.xml (new "MYRA Keyboard" card), SettingsActivity.kt (click listener)

## MYRA Keyboard update (fixed height, swipe pages, 3D keys, Islamic, symbols)
- keyboard/MyraKeyboardService.kt – keyboard + emoji/clipboard/theme panels now have ONE fixed pixel height (4 rows + padding); emoji panel is a left/right swipe pager (each category = one page, scroll up/down inside a page); tab bar and delete/ABC in one row
- keyboard/MyraKeyboardView.kt – ultra 3D keys: soft shadow, side wall, rim colour follows theme accent, glossy face, text shadow
- keyboard/KbPages.kt (new) – page data: emoji, Kalimat, Durood Sharif, Zikr/Dua, Islamic symbols, 500+ unique symbols (arrows, math, shapes, stars, currency, boxes, decor brackets, kaomoji)
- keyboard/KbEmojiUi.kt (new) – adapters for the pages
- keyboard/KbThemes.kt – every theme defaults to 3D keys
- keyboard/KbRootLayout.kt – removed the extra dark overlay on the background image
- assets/keyboard/bg_*.jpg + pv_*.jpg – 14 new 2160x1400 designs (galaxy, aurora, sunset, ocean, gold, emerald, rosebokeh, synthwave, marble, carbon, ice, lavender, islamic, crimson); KbThemes.kt registers each with its own matching key / box / text / border colours
- keyboard/KbFonts.kt (new) – 30 decoration font styles (꧁ABC꧂ etc.) + 17 more letter fonts (bold, script, gothic, circle, small caps...); KbPrefs.fontStyle remembers the choice
- keyboard/MyraKeyboardService.kt – new "Aa" toolbar button + Font Style panel; live typing in the chosen style (per word), Convert button for selected/whole text
- keyboard/MyraKeyboardView.kt – 4 new key designs: Jewel (silver key, pearl border, heart), Neon (glowing coloured border), Rainbow (animated moving rainbow border), Glossy (black glass); keys show the chosen font letters
- keyboard/KbFonts.kt – 30 different letter fonts (no symbol wrappers); hidden automatically if the phone cannot draw them
- keyboard/KbSuggest.kt (new) + service – suggestion strip above the keys (3 words; learns the words you type)
- assets/keyboard – 3 new designs: neonlights, pinkgalaxy, diamondheart
- Old plain key styles (3D / glass / flat / bubble) retired: every theme now uses the shiny Jewel / Neon / Rainbow / Glossy key designs (+ corner star glints)
- keyboard/KbShiny.kt (new) – shiny 3D button look (shadow, thick wall, coloured rim, gloss, pearls, glints) used by toolbar buttons, suggestion words, panel buttons, font rows and symbol boxes
- KbFonts: all 30 fonts are always listed (the old glyph filter wrongly hid them)
- Keyboard now sits above the system bottom buttons (window insets padding); softer tinted key shadows + inner bevel on Jewel keys; suggestions are inside ONE always-visible shiny box
- Removed the extra "ALL" toolbar button (long-press select all already exists)
- Key sound now works (SoundPool, independent of phone touch-sound setting): 14 different sounds in res/raw/ksnd_01..14.wav, chooser + volume slider in Keyboard Settings > Options (keyboard/KbSound.kt)
- Clipboard: unlimited history (file based, up to 5000 items), scrollable list, tap = paste, long-press = delete (keyboard/KbClips.kt)
- API keys: assets/keys.txt has ❤️ placeholders (GEMINI_KEY / WEB_BUILDER_KEY / SUPABASE_KEY); replace in the built APK with MT Manager. Real keys removed from source (utils/Keys.kt, ApiKeys, CloudConfig, backend/admin/firebase-config.js)
- Web Builder (webbuilder/WebBuilderActivity.kt): prompt -> AI builds modern website, live preview, change requests, ZIP save; button in Settings
- App Lock now really works: locked apps are enforced by AppLockGuard (accessibility service) - lock screen appears when a locked app opens
- Private Vault (security/VaultActivity.kt): hide photos / videos / music / files in app-private storage behind the lock; card in Settings
- Keys: also work when edited inside the code with MT Manager (placeholders ❤️1 Gemini / ❤️2 Web Builder / ❤️3 Supabase) or in assets/keys.txt; Web Builder key field is now the main (easiest) way and the error message no longer contains the heart
- Fixed app closing on first launch while permission dialogs are open: microphone / phone-call foreground services no longer crash before permission is granted (utils/FgsSafe.kt, services guarded, onDestroy guarded, manifest specialUse fallback)
- Web Builder: keys starting with AQ. (Google Cloud / Vertex AI express keys) now use the Vertex endpoint first, the normal Gemini endpoint as fallback; error screen shows both messages
